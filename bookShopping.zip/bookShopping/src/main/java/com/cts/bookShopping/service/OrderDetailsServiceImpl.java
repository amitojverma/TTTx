package com.cts.bookShopping.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.cts.bookShopping.bean.OrderDetails;
import com.cts.bookShopping.dao.BooksDAO;
import com.cts.bookShopping.dao.OrderDetailsDAO;

@Service("orderDetailsService")
@Transactional(propagation = Propagation.SUPPORTS)
public class OrderDetailsServiceImpl implements OrderDetailsService {

	@Autowired
	private OrderDetailsDAO booksDAO;
	@Override
	public String insertDetails(OrderDetails books) {
		// TODO Auto-generated method stub
		return booksDAO.insertDetails(books);
	}
	@Override
	public List<OrderDetails> displayDetails(String emailId) {
		// TODO Auto-generated method stub
		return booksDAO.displayDetails(emailId);
	}
	@Override
	public String deleteOrderItem(int id) {
		// TODO Auto-generated method stub
		return booksDAO.deleteOrderItem(id);
	}

}
