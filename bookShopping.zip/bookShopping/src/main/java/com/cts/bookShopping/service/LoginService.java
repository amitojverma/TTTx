package com.cts.bookShopping.service;


import com.cts.bookShopping.bean.userRegistration;

public interface LoginService {
	public userRegistration authenticate(String emailId, String password);
}
