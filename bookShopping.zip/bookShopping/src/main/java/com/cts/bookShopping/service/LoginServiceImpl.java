package com.cts.bookShopping.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.cts.bookShopping.bean.login;
import com.cts.bookShopping.bean.userRegistration;
import com.cts.bookShopping.dao.LoginDAO;

@Service("loginService")
@Transactional(propagation = Propagation.SUPPORTS)
public class LoginServiceImpl implements LoginService{
	@Autowired
	LoginDAO loginDAO;
	@Override
	public userRegistration authenticate(String emailId, String password) {
		// TODO Auto-generated method stub
		return loginDAO.authenticate(emailId, password);
	}

}
