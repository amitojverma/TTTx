package com.cts.bookShopping.service;

import java.util.List;

import com.cts.bookShopping.bean.AddToCart;

public interface AddToCartService {
	public String addCartDetails(AddToCart add);
	public List<AddToCart> viewCartDetails(String id);
	public String deleteCartItem(int id);
	public String totalPrice(String id);
}
